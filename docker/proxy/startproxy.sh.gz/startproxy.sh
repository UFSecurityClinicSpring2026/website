cd /opt/caddy/
caddy start
