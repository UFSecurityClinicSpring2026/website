echo $FILE_ENCRYPTION_SECRET | cryptsetup luksOpen -q /opt/website/data/examstorage.enc examstorage
mkdir /opt/website/securedata
mount /dev/mapper/examstorage /opt/website/securedata

cd /opt/website
python3 questionimport.py data/questions.csv
waitress-serve --listen=[::]:8080 app:app