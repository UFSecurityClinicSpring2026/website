dd if=/dev/zero of=/opt/website/data/examstorage.enc bs=1M count=256 status=progress
echo $FILE_ENCRYPTION_SECRET | cryptsetup luksFormat -q /opt/website/data/examstorage.enc
echo $FILE_ENCRYPTION_SECRET | cryptsetup luksOpen -q /opt/website/data/examstorage.enc examstorage
mkfs -t ext4 /dev/mapper/examstorage
cryptsetup luksClose examstorage